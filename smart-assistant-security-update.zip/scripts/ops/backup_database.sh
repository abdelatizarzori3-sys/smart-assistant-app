#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?Set DATABASE_URL at runtime}"
: "${BACKUP_BUCKET:?Set BACKUP_BUCKET at runtime}"
: "${BACKUP_KMS_KEY_ID:?Set BACKUP_KMS_KEY_ID at runtime}"

mkdir -p "${BACKUP_DIR:-/tmp/smart-assistant-backups}"
out="${BACKUP_DIR:-/tmp/smart-assistant-backups}/backup-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"

mysqldump --single-transaction --routines --triggers "$DATABASE_URL" | gzip -9 > "$out"
aws s3 cp "$out" "s3://${BACKUP_BUCKET}/database/" --sse aws:kms --sse-kms-key-id "$BACKUP_KMS_KEY_ID" --only-show-errors
shred -u "$out"
echo "BACKUP_OK"
