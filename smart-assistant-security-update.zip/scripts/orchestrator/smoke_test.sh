#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:?Set BASE_URL to the deployed application URL}"
TIMEOUT="${SMOKE_TIMEOUT_SECONDS:-20}"

check() {
  local path="$1"
  local status
  status="$(curl -L -sS --max-time "$TIMEOUT" -o /tmp/smart-assistant-smoke-response -w '%{http_code}' "$BASE_URL$path")"
  [[ "$status" == "200" ]] || { echo "SMOKE_FAILED path=$path status=$status" >&2; return 1; }
  grep -qi '<html' /tmp/smart-assistant-smoke-response || { echo "SMOKE_FAILED path=$path missing HTML" >&2; return 1; }
  echo "SMOKE_OK path=$path status=$status"
}

check "/"
check "/health"
check "/workspace"
