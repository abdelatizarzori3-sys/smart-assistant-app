# حوكمة GitHub

فعّل حماية فرع `main` من إعدادات المستودع، واجعل طلب سحب ومراجعة واحدة على الأقل مطلوبة، وفعّل نتائج `تحقق مستمر` و`فحص أمني وتبعيات` كفحوص إلزامية. امنع الدفع المباشر، وامنع تجاوز حماية الفرع إلا لحسابات الطوارئ المسجلة.

أضف شارة التحقق إلى README بعد تفعيل المستودع:

```markdown
[![CI](https://github.com/abdelatizarzori3-sys/smart-assistant-app/actions/workflows/ci.yml/badge.svg)](https://github.com/abdelatizarzori3-sys/smart-assistant-app/actions/workflows/ci.yml)
[![Security](https://github.com/abdelatizarzori3-sys/smart-assistant-app/actions/workflows/security.yml/badge.svg)](https://github.com/abdelatizarzori3-sys/smart-assistant-app/actions/workflows/security.yml)
```

تُرفع تقارير تغطية الاختبارات بعد إضافة مزود تغطية متوافق مع Vitest. لا يُعلن عن نسبة تغطية قبل تشغيل القياس فعليًا.
